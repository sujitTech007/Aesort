







    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js.download"></script>

    <!-- App js -->
    <script src="assets/js/app.js.download"></script>

    <!-- Apex Chart js -->
    <script src="assets/js/apexcharts.min.js.download"></script>

    <!-- Projects Analytics Dashboard App js -->
    <script src="assets/js/dashboard.js.download"></script>



    <script>
        $('.accordian-body').on('show.bs.collapse', function () {
            $(this).closest("table")
                .find(".collapse.in .action")
                .not(this)
                .collapse('toggle')
        })
    </script>
    
</body>

</html>