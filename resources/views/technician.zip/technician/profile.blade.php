@include('technician.include.header')


        <div class="page-content">


            <div class="page-title-head d-flex align-items-center gap-2">
                <div class="flex-grow-1">
                    <h4 class="fs-18 fw-bold mb-0 py-2">Profile</h4>
                </div>

                <div class="text-end">
                    <ol class="breadcrumb m-0 py-0 fs-13">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Aeshort</a></li>

                        <li class="breadcrumb-item active">Profile</li>
                    </ol>
                </div>
            </div>

            <div class="page-container">

                 <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Admin" class="rounded-circle" width="150">
                    <div class="mt-3 pb-4">
                      <h4>John Doe</h4>
                      <p class="text-secondary mb-1">Full Stack Developer</p>
                      <p class="text-muted font-size-sm">Bay Area, San Francisco, CA</p>
                      
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      Kenneth Valdez
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Email</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      fip@jukmuh.al
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Phone</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      (239) 816-9029
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Mobile</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      (320) 380-4539
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Address</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      Bay Area, San Francisco, CA
                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-12">
                      <a class="btn btn-info " target="__blank" href="https://www.bootdey.com/snippets/view/profile-edit-data-and-skills">Edit</a>
                    </div>
                  </div>
                </div>
              </div>








            </div>








            

        </div>


    </div>
    <!-- END wrapper -->



    <div class="modal fade" id="exampleModalView" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Application Number NP/2010/2025</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="modalListViwe-box">

                        <div class="tableStatusList mb-1">
                            <div class="row justify-content-between px-3">
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Discom:</h5>
                                    <p>Chandigarh Electricity dipartiment</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Application No:</h5>
                                    <p>NP/1020/2025</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>State:</h5>
                                    <p>Chandigarh</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Circle:</h5>
                                    <p>CREST</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Subsidy Amount(in Rs):</h5>
                                    <p>54,000</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Distric:</h5>
                                    <p>Chandigarh</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Division:</h5>
                                    <p>Division 4</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Existing Installed Capacity(kwp):</h5>
                                    <p>0.000</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Pincode:</h5>
                                    <p>160030</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Subdivision:</h5>
                                    <p>Sub Division office 4</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Proposed Capacity(kwp):</h5>
                                    <p>3.000</p>
                                </div>
                                <div class="col-md-6 d-flex justify-content-start align-items-center py-1">
                                    <h5>Approved Capacity(kwp):</h5>
                                    <p>3.000</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModalEdit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Edit Application</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="card-body">
                        <form action="#">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="applicationNo" class="form-label">Application No</label>
                                    <input type="text" class="form-control" id="applicationNo"
                                        placeholder="Enter Application No" value="NP/1020/2025">
                                </div>
                                <div class="col-md-6">
                                    <label for="consumerNo" class="form-label">Consumer No</label>
                                    <input type="text" class="form-control" id="consumerNo"
                                        placeholder="Enter Consumer No" value="443346567568">
                                </div>
                                <div class="col-md-6 mt-2">
                                    <label for="circle" class="form-label">Circle</label>
                                    <input type="text" class="form-control" id="circle" placeholder="Enter Circle"
                                        value="CREST">
                                </div>
                                <div class="col-md-6 mt-2">
                                    <label for="division" class="form-label">Division</label>
                                    <input type="text" class="form-control" id="division" placeholder="Enter Division"
                                        value="Division 4">
                                </div>
                                <div class="col-md-6 mt-2">
                                    <label for="subDivision" class="form-label">Sub Division</label>
                                    <input type="text" class="form-control" id="subDivision"
                                        placeholder="Enter Sub Division" value="Sub Division Office 4">
                                </div>
                                <div class="col-md-6 mt-2">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" aria-label="Default select example">
                                        <option selected>Open this select menu</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>

                                <div
                                    class="modal-footer mt-4 border-0 d-flex align-items-center justify-content-center">
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">Save changes</button>
                                </div>

                        </form>
                    </div>

                </div>

            </div>
        </div>
    </div>
@include('technician.include.footer')
